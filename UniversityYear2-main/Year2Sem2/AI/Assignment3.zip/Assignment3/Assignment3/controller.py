from repository import *


class controller():
    def __init__(self, args):
        self.__repository = args[0]
        self.__m = args[1]
    
    # crosover the top 2 from a population and with the new genration we try to mutate them( along with the population) and then
    # we add the new generation into our list and we remove the 2 weak ones.
    def iteration(self):
        latestGeneration = self.__repository.getPopulationLast()
        parents = latestGeneration.selection(2)

        offspring1, offspring2 = parents[0].crossover(parents[1])
        newGeneration = latestGeneration.copy()

        newGeneration.addIndividual(offspring1)
        newGeneration.addIndividual(offspring2)

        newGeneration.tryMutate()

        newGeneration.evaluate()

        newGeneration.removeWeakest()
        newGeneration.removeWeakest()

        self.__repository.savePopulation(newGeneration)
        return newGeneration
    #if the fitness has not changed in thepast 5 iterations than the app stops.
    def run(self):
        noChangeIterations = 0
        maximumFitness = 0
        gen = None
        while True:
            gen = self.iteration()
            if gen.getMaxFitness() > maximumFitness:
                maximumFitness = gen.getMaxFitness()
                noChangeIterations = 0
            else:
                noChangeIterations += 1
                if noChangeIterations > 5:
                    break
        return gen
    
    #we create the initial population 
    #and we get the best fitness & path from the population we created( randomly)
    def solver(self, args):
        self.__repository.clearPopulations()
        initialPopulation = Population(self.__repository.getMap(), args[0], self.__repository.getMap().m * self.__repository.getMap().n, self.__m)
        initialPopulation.evaluate()
        self.__repository.savePopulation(initialPopulation)

        gen = self.run()

        best = gen.selection(1)[0]
        path = best.getPath()
        fitness = best.getF()
        
        return [path, fitness]