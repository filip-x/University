# -*- coding: utf-8 -*-

import pickle
from domain import *


class repository():
    def __init__(self):
        self.__populations = []
        self.__cmap = None

    def setDomainSeed(self,x):
        setSeed(x)

    def createPopulation(self, args):
        # args = [populationSize, individualSize] -- you can add more args    
        return Population(args[0], args[1])
        
    def clearPopulations(self):
        self.__populations.clear()

    def generateRandomMap(self,args):
        self.__cmap = Map(args[0],args[1])
        self.getMap().randomMap(args[2])
    
    def loadMap(self,fileN):
        self.__cmap = Map()
        self.getMap().loadMap(fileN)
    
    def saveMap(self,fileN):
        if self.getMap():
            self.getMap().saveMap(fileN)

    def getPopulationLast(self):
        return self.__populations[-1]

    def savePopulation(self,pop):
        self.__populations.append(pop)

    def getMap(self):
        return self.__cmap
    # TO DO : add the other components for the repository: 
    #    load and save from file, etc
            