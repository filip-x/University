# -*- coding: utf-8 -*-

# imports
from gui import *
from controller import *
from repository import *
from domain import *
import numpy as np
import matplotlib.pyplot as pyplot

class Ui:

    def __init__(self):
        self.repo = repository()
        self.controller = None
        self.solveParams = None

    def menuPrint(self):
        print("0.Exit")
        print("1.Map options")
        print("2.EA options")
    
    def MapPrint(self):
        print("1. Create a random map")
        print("2. Load a map")
        print("3. Save a map")
        print("4. Visualize a map")
        print("0. Go back to previous menu")  

    def EAPrint(self):
        print("1. Setup parameters")
        print("2. Run the solver")
        print("3. Visualize the statistics")
        print("4. View the drone moving on a path")
        print("0. Go back to previous menu")

    def menuMap(self):
        while True:
            self.MapPrint()
            try:
                choice = int(input("Choose a number: "))
                if choice == 0:
                    return
                elif choice == 1:
                    self.generateRandomMap()
                elif choice == 2:
                    self.loadMap()
                elif choice == 3:
                    self.saveMap()
                elif choice == 4:
                    self.visualiseMap()
                else:
                    print("This number is not registered")
            except Exception as e:
                print("An Error has occured: "+ e)

    def menuEA(self):
        while True:
            self.EAPrint()
            try:
                choice = int(input("Choose a number: "))
                if choice == 0:
                    return
                elif choice == 1:
                    self.setupParams()
                elif choice == 2:
                    self.runSolver()
                elif choice == 3:
                    self.statisticsVisualize()
                elif choice == 4:
                    self.movOnPath()
                else:
                    print("This number is not registered")
            except Exception as e:
                print("An Error has occured: "+ e)



    def displayMenu(self):
        while True:
            self.menuPrint()
            try:
                choice = int(input("Choose a number: "))
                if choice == 0:
                    return
                elif choice == 1:
                    self.menuMap()
                elif choice == 2:
                    self.menuEA()
                else:
                    print("This number is not registered")
            except Exception as e:
                    print("An Error has occured: "+ e)

    def generateRandomMap(self):
        n = int(input("N= "))
        m = int(input("M= "))
        wall = float(input("Wall chance from 0 to 1: "))
        self.repo.generateRandomMap([n,m,wall])

    def saveMap(self):
        fileN = input("Enter file name:")
        self.repo.saveMap(fileN)
    
    def loadMap(self):
        fileN = input("Enter file name:")
        self.repo.loadMap(fileN)
    
    def visualiseMap(self):
        print(self.repo.getMap())
    
    def setupParams(self):
        self.solveParams= [self.repo,int(input("M= "))]
        self.controller = controller(self.solveParams)

    def runSolver(self):
        if self.controller == None or self.repo.getMap() == None:
            raise Exception("Missing param or map !")
        else:
            start = []
            print("Start point: ")
            start.append(int(input("  X= ")))
            start.append(int(input("  Y= ")))
            self.controller.solver([start])
    
    def statisticsVisualize(self):
        if self.controller == None or self.repo.getMap() == None:
            raise Exception("Missing parm or map  !")
        else:
            start = []
            print("Start point: ")
            start.append(int(input("  X= ")))
            start.append(int(input("  Y= ")))
            seed = [0, 11, 25, 100, 254, 91, 84, 1212, 542, 210,
                1232, 890, 12, 4, 21345, 310932, 123321, 54145, 1234, 11111,
                1337, 891834, 123423, 135633, 12343, 123432, 94747, 92921, 111, 13213444]
            f = []
            for s in seed:
                self.repo.setDomainSeed(s)
                info = self.controller.solver([start])
                f.append(info[1])

            x = [i for i in range(len(seed))]
            avg = np.average(f)
            stdev = np.std(f)
            print("Average:{0}, Stedv:{1}". format(avg,stdev))
            pyplot.plot(x,f)
            pyplot.show()
        
    def movOnPath(self):
        if self.controller == None or self.repo.getMap() == None:
            raise Exception("Missing para or map !")
        else:
            start = []
            print("Start point: ")
            start.append(int(input("  X= ")))
            start.append(int(input("  Y= ")))
            info = self.controller.solver([start])
            print(*info)
            movingDrone(self.repo.getMap(),info[0])

def main():
    ui = Ui()
    ui.displayMenu()

main()

#Done
# create a menu
#   1. map options:
#         a. create random map
#         b. load a map
#         c. save a map
#         d visualise map
#   2. EA options:
#         a. parameters setup
#         b. run the solver
#         c. visualise the statistics
#         d. view the drone moving on a path
#              function gui.movingDrone(currentMap, path, speed, markseen)
#              ATENTION! the function doesn't check if the path passes trough walls