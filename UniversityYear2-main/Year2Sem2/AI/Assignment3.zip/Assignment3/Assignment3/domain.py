# -*- coding: utf-8 -*-

from random import *
from utils import *
import numpy as np

# the glass gene can be replaced with int or float, or other types
# depending on your problem's representation

def setSeed(val):  
    np.random.seed(val)

class gene:
    def __init__(self, directionE = None):
        if directionE == None:
            self.direction = np.random.randint(0, len(v))
        else:
            self.direction = directionE
    
    def __eq__(self, other):
        if self.direction == other.direction:
            return True
        return False

    def __hash__(self):
        return hash("{0}".format(self.direction))

class Individual:
    def __init__(self, mapM, startPoint, size = 0):
        self.__size = size
        self.__x = [gene() for i in range(self.__size)]#all random 
        self.__f = None
        self.__mapM = mapM
        self.__start = startPoint
    
    def fitness(self):#colors all points that the dronegoes to(lines and columns)
        exploredPoints = []
        previous = self.__start
        exploredPoints.append(self.__start)
        penalties = 0
        for g in self.__x:
            d = directionsDict[g.direction]
            genePos = [previous[0] + d[0], previous[1] + d[1]]
            exploredPoints.append(genePos)
            previous = genePos
            if not (genePos[0] >= 0 and genePos[0] < self.__mapM.n and genePos[1] >= 0 and genePos[1] < self.__mapM.m and self.__mapM.surface[genePos[0]][genePos[1]] == 0):
                penalties += 1
            for i in range(len(directionsList)):
                t = v[i]
                p = [genePos[0] + t[0], genePos[1] + t[1]]
                while p[0] >= 0 and p[0] < self.__mapM.n and p[1] >= 0 and p[1] < self.__mapM.m and self.__mapM.surface[p[0]][p[1]] == 0 and not p in exploredPoints:
                    exploredPoints.append(p)
                    p = [p[0] + t[0], p[1] + t[1]]
        self.__f = len(exploredPoints) - penalties * 10
        # so wehn we have much more colors in the map then the fitness is better 
        #if we hit the wall weget penalities *10
    def getX(self):
        return self.__x

    def getSize(self):
        return self.__size

    def mutate(self, mutateProbability = 0.04): 
        for i in range(len(self.__x)):
            if random() < mutateProbability:
                k = np.random.randint(0, len(directionsList))
                self.__x[i] = gene(directionsList[k])
        
    
    def crossover(self, otherParent, crossoverProbability = 0.8):# we get random number parts
        # we split the parent in k parts and we switch them 
        offspring1, offspring2 = Individual(self.__mapM, self.__start, self.__size), Individual(self.__mapM, self.__start, self.__size)
        if random() < crossoverProbability:
            offspring1.getX().clear()
            offspring2.getX().clear()
            nextCut = np.random.randint(1, self.getSize() - 1)
            previousCut = 0
            k = True
            while nextCut < self.getSize() - 1:
                if k == 1:
                    for e in self.getX()[previousCut:nextCut]:
                        offspring1.getX().append(e)
                    for e in otherParent.getX()[previousCut:nextCut]:
                        offspring2.getX().append(e)
                else:
                    for e in self.getX()[previousCut:nextCut]:
                        offspring2.getX().append(e)
                    for e in otherParent.getX()[previousCut:nextCut]:
                        offspring1.getX().append(e)
                k = not k
                previousCut = nextCut
                nextCut = np.random.randint(previousCut + 1, self.getSize())
            while (s := offspring1.getSize()) < self.getSize():
                offspring1.getX().append(self.getX()[s])
                offspring2.getX().append(otherParent.getX()[s])        
        return offspring1, offspring2
    
    def getPath(self):# we get the path ( points ) and we get them into a list(path)
        path = []
        previous = self.__start
        path.append(self.__start)
        for g in self.__x:
            d = directionsDict[g.direction]
            genePos = [previous[0] + d[0], previous[1] + d[1]]
            previous = genePos
            path.append(genePos)
        return path
    
    def copy(self): # copys the individual(the directions and fitness)
        cloned = Individual(self.__mapM, self.__start, self.__size)
        cloned.getX().clear()
        e = cloned.getX() 
        e += self.getX()
        return cloned
    
    def getF(self):
        return self.__f
    
class Population():# list of individuals
    def __init__(self, mapM, startPoint, populationSize = 0, individualSize = 0):
        self.__populationSize = populationSize
        self.__individualSize = individualSize
        self.__mapM = mapM
        self.__startPoint = startPoint
        self.__v = [Individual(mapM, startPoint, individualSize) for x in range(populationSize)]
        self.__maxFitness = 0
    
    def copy(self):
        newPop = Population(self.__mapM, self.__startPoint, self.__populationSize, self.__individualSize)
        newPop.getIndividuals().clear()
        for x in self.__v:
            newPop.getIndividuals().append(x.copy())
        return newPop

    def getMaxFitness(self):#we get the best fitness in the list 
        return self.__maxFitness

    def removeWeakest(self): # we remove the weakeste fitness in the list 
        weakest = min(self.__v, key=lambda i: i.getF())
        self.__v.remove(weakest)
    
    def addIndividual(self, ind):#we add indivitual in the list 
        self.__v.append(ind)
    
    def tryMutate(self): # we try to mutate the list
        for x in self.__v:
            x.mutate()

    def getIndividuals(self): # return the list
        return self.__v

    def evaluate(self): # we get the fitness of all roads  and we save the biggest fitness
        # evaluates the population
        for x in self.__v:
            x.fitness()
            if x.getF() > self.__maxFitness:
                self.__maxFitness = x.getF()
            
    def selection(self, k = 0):# we sortthe individuals and we return k individuals (from top)
        if k == 0:
            return []
        e = self.__v[:]
        e.sort(key=lambda x: x.getF(), reverse=True)
        return e[:k]
    
class Map():
    def __init__(self, n = 20, m = 20):
        self.n = n
        self.m = m
        self.surface = np.zeros((self.n, self.m))
    
    def randomMap(self, fill = 0.2):# it generates a random map 
        for i in range(self.n):
            for j in range(self.m):
                if random() <= fill :
                    self.surface[i][j] = 1
                
    def __str__(self): # we print the map 
        string = ""
        for i in range(self.n):
            for j in range(self.m):
                string = string + str(int(self.surface[i][j]))
            string = string + "\n"
        return string
    
    def loadMap(self, fileName): # load the map from a file (main.map)
        file = open(fileName, "r")
        line = file.readline()
        l = line.split(" ")
        n, m = l[0], l[1]
        n = int(n)
        m = int(m)
        self.n = n
        self.m = m
        for i in range(n):
            line = file.readline().split(" ")
            for j in range(m):
                self.surface[i][j] = int(line[j])
        file.close()
    
    def saveMap(self, fileName): # we save the map from the file 
        file = open(fileName, "w")
        file.write("{0} {1}\n".format(self.n, self.m))
        string = ""
        for i in range(self.n):
            for j in range(self.m):
                string = string + str(int(self.surface[i][j])) + " "
            string = string + "\n"
        file.write(string)
        file.close()
    