from domain import Map


class Repository:
    def __init__(self):
        self.__current_map = None

    def generate_random_map(self, args):
        self.__current_map = Map(args[0], args[1])
        self.get_map().random_map(args[2])

    def load_map(self, file_name):
        self.__current_map = Map()
        self.get_map().load_map(file_name)

    def save_map(self, file_name):
        if self.get_map():
            self.get_map().save_map(file_name)
        else:
            raise Exception("No map to save.")

    def get_map(self):
        return self.__current_map

    def set_map(self, new_map):
        self.__current_map = new_map
