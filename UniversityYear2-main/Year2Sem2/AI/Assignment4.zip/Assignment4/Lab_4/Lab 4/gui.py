# -*- coding: utf-8 -*-

import pygame
from EvolutinLab3.domain import *


class PyGameGui:
    def __init__(self, dimension):
        # init the pygame
        pygame.init()
        logo = pygame.image.load("logo32x32.png")
        pygame.display.set_icon(logo)
        pygame.display.set_caption("Drone Exploration")

        # create a surface on screen that has the size of 800 x 480
        self.__screen = pygame.display.set_mode(dimension)
        self.__screen.fill(WHITE)

    def get_screen(self):
        return self.__screen

    @staticmethod
    def slow_sleep(seconds):
        t = pygame.time.get_ticks()
        while pygame.time.get_ticks() < t + seconds * 1000:
            pygame.event.get()

    @staticmethod
    def close_py_game():
        # closes the pygame
        running = True
        # loop for events
        while running:
            # event handling, gets all event from the event queue
            for event in pygame.event.get():
                # only do something if the event is of type QUIT
                if event.type == pygame.QUIT:
                    # change the value to False, to exit the main loop
                    running = False
        pygame.quit()


class MovingDrone(PyGameGui):

    def __init__(self, current_map, path, speed=1, mark_seen=True):  # noqa
        self.__current_map = current_map
        super().__init__((current_map.n * 20, current_map.m * 20))

        drona = pygame.image.load("drona.png")
        brick2 = pygame.Surface((20, 20))
        brick2.fill(RED)
        for i in range(len(path)):
            self.get_screen().blit(self.__generate_image(), (0, 0))

            if mark_seen:
                brick = pygame.Surface((20, 20))
                brick.fill(GREEN)
                for j in range(i + 1):
                    for var in v:
                        x = path[j][0]
                        y = path[j][1]
                        while ((0 <= x + var[0] < current_map.n and
                                0 <= y + var[1] < current_map.m) and
                               current_map.surface[x + var[0]][y + var[1]] != 1):
                            x = x + var[0]
                            y = y + var[1]
                            self.get_screen().blit(brick, (y * 20, x * 20))
            for j in range(i + 1):
                x = path[j][0]
                y = path[j][1]
                self.get_screen().blit(brick2, (y * 20, x * 20))
            self.get_screen().blit(drona, (path[i][1] * 20, path[i][0] * 20))
            pygame.display.flip()
            # time.sleep(0.5 * speed)
            PyGameGui.slow_sleep(0.5 * speed)

        PyGameGui.close_py_game()

    def get_map(self):
        return self.__current_map

    def __generate_image(self, colour=BLUE, background=WHITE):
        # creates the image of a map

        imagine = pygame.Surface((self.get_map().n * 20, self.get_map().m * 20))
        brick = pygame.Surface((20, 20))
        brick.fill(colour)
        imagine.fill(background)
        for i in range(self.get_map().n):
            for j in range(self.get_map().m):
                if self.get_map().surface[i][j] == 1:
                    imagine.blit(brick, (j * 20, i * 20))

        return imagine


def get_max(matrix, size):
    maxim = -1
    for i in range(size):
        for j in range(size):
            if matrix[i][j] > maxim:
                maxim = matrix[i][j]
    return maxim


def clamp(value, minim, maxim):
    if value < minim:
        value = minim
    if value > maxim:
        value = maxim
    return value


def int_clamp(value, minim, maxim):
    if value < minim:
        value = minim
    if value > maxim:
        value = maxim
    return int(value)


class ShowPheromoneMap(PyGameGui):

    def __init__(self, pheromone_map, current_map, sensors, path, sensor_energy):  # noqa
        super().__init__((pheromone_map.get_size() * 20, pheromone_map.get_size() * 20))
        self.__current_map = pheromone_map
        self.get_screen().blit(self.__generate_image(), (0, 0))

        self.moving_drone(current_map, path, sensors, sensor_energy)
        PyGameGui.close_py_game()

    def get_map(self):
        return self.__current_map

    def __generate_image(self, colour=BLUE, background=WHITE):
        imagine = pygame.Surface((self.get_map().get_size() * 20, self.get_map().get_size() * 20))

        brick = pygame.Surface((20, 20 * self.get_map().get_size()))
        brick.fill(colour)
        imagine.fill(background)
        return imagine

    def build_moving_drone(self, current_map):
        sensor_brick = pygame.Surface((20, 20))
        sensor_brick.fill(pygame.Color(255, 255, 0))

        brick = pygame.Surface((20, 20))
        brick.fill(pygame.Color(0, 0, 0))

        for i in range(current_map.get_size()):
            for j in range(current_map.get_size()):
                if current_map.get_point_value([i, j]) == 1:
                    self.get_screen().blit(brick, (j * 20, i * 20))
                if current_map.get_point_value([i, j]) == -10:
                    self.get_screen().blit(sensor_brick, (j * 20, i * 20))

    def display_coverage_moving_drone(self, sensors, sensor_energy, current_map):
        coverage_brick = pygame.Surface((20, 20))
        coverage_brick.fill(pygame.Color(201, 255, 184))
        for sensor in sensors:
            for variation in v:
                d = tuple(sensor)
                if tuple(sensor) in sensor_energy:
                    for i in range(1, sensor_energy[tuple(sensor)][0] + 1):
                        d = (d[0] + variation[0], d[1] + variation[1])
                        if current_map.point_is_valid(d) and current_map.get_point_value(d) != 1:
                            self.get_screen().blit(coverage_brick, (d[1] * 20, d[0] * 20), )
                        else:
                            break

    def display_coverage_moving_drone_slow(self, sensor, sensor_energy, current_map):
        coverage_brick = pygame.Surface((20, 20))
        coverage_brick.fill(pygame.Color(201, 255, 184))
        blocked_direction = {}
        for i in range(1, sensor_energy[tuple(sensor)][0] + 1):
            if tuple(sensor) in sensor_energy:
                for variation in v:
                    if tuple(variation) not in blocked_direction:
                        d = tuple(sensor)
                        d = (d[0] + variation[0] * i, d[1] + variation[1] * i)
                        if current_map.point_is_valid(d) and current_map.get_point_value(d) != 1:
                            self.get_screen().blit(coverage_brick, (d[1] * 20, d[0] * 20), )
                        else:
                            blocked_direction[tuple(variation)] = True
                pygame.display.flip()
                PyGameGui.slow_sleep(0.5 * 1)

    def moving_drone(self, current_map, path, sensors, sensor_energy):
        drona = pygame.image.load("drona.png")
        brick2 = pygame.Surface((20, 20))
        brick2.fill(RED)
        speed = 1
        sensors_so_far = []
        for i in range(len(path)):
            self.get_screen().blit(self.__generate_image(), (0, 0))
            brick = pygame.Surface((20, 20))
            brick.fill(GREEN)
            self.display_coverage_moving_drone(sensors_so_far, sensor_energy, current_map)
            for j in range(i + 1):
                move = path[j]
                self.get_screen().blit(brick, (move[1] * 20, move[0] * 20))

            self.build_moving_drone(current_map)
            if path[i] in sensors:
                sensors_so_far.append(path[i])
                self.display_coverage_moving_drone_slow(path[i], sensor_energy, current_map)

            self.get_screen().blit(drona, (path[i][1] * 20, path[i][0] * 20))
            pygame.display.flip()
            PyGameGui.slow_sleep(0.5 * speed)
