from random import *
import numpy as np


class Map:
    def __init__(self, n=20, m=20):
        self.n = n
        self.m = m
        self.surface = np.zeros((self.n, self.m))

    def random_map(self, fill=0.2):
        for i in range(self.n):
            for j in range(self.m):
                if random() <= fill:
                    self.surface[i][j] = 1

    def __str__(self):
        string = ""
        for i in range(self.n):
            for j in range(self.m):
                string = string + str(int(self.surface[i][j]))
            string = string + "\n"
        return string

    def load_map(self, file_name):
        file = open(file_name, "r")
        line = file.readline()
        line = line.split(" ")
        n, m = line[0], line[1]
        n = int(n)
        m = int(m)
        self.n = n
        self.m = m
        for i in range(n):
            line = file.readline().split(" ")
            for j in range(m):
                self.surface[i][j] = int(line[j])
        file.close()

    def save_map(self, file_name):
        file = open(file_name, "w")
        file.write("{0} {1}\n".format(self.n, self.m))
        string = ""
        for i in range(self.n):
            for j in range(self.m):
                string = string + str(int(self.surface[i][j])) + " "
            string = string + "\n"
        file.write(string)
        file.close()

    def point_is_valid(self, p):
        return 0 <= p[0] < self.n and 0 <= p[1] < self.m

    def get_point_value(self, p):
        return self.surface[p[0]][p[1]]

    def get_size(self):
        return self.n

    def set_point(self, x, y, value):
        self.surface[x][y] = value
