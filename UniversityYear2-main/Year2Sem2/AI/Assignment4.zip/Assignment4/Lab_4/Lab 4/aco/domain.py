from utils import *
import numpy as np


def manhattan(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])


class PheromoneMap:
    def __init__(self, n):
        self.__size = n
        self.__intensity_map = np.zeros((n, n))
        self.__quantity_map = np.zeros((n, n))

    def get_size(self):
        return self.__size

    def get_intensity_map(self):
        return self.__intensity_map

    def get_quantity_map(self):
        return self.__quantity_map

    def set_pheromone_intensity(self, i, j, value):
        if 0 <= i < self.get_size() and 0 <= j < self.get_size():
            self.__intensity_map[i][j] = value

    def get_pheromone_intensity(self, i, j):
        if 0 <= i < self.get_size() and 0 <= j < self.get_size():
            return self.__intensity_map[i][j]

    def set_pheromone_quantity(self, i, j, value):
        if 0 <= i < self.get_size() and 0 <= j < self.get_size():
            self.__quantity_map[i][j] = value

    def increase_pheromone_quantity(self, i, j):
        if 0 <= i < self.get_size() and 0 <= j < self.get_size():
            self.__quantity_map[i][j] += 1

    def get_pheromone_quantity(self, i, j):
        if 0 <= i < self.get_size() and 0 <= j < self.get_size():
            return self.__quantity_map[i][j]

    def get_pheromone_value(self, i, j):
        if 0 <= i < self.get_size() and 0 <= j < self.get_size():
            return self.get_pheromone_intensity(i, j) ** self.get_pheromone_quantity(i, j)


class Ant:
    def __init__(self, start_point, pheromone_map, current_map, sensors, alpha, beta, battery, repository,
                 initial_intensity):
        self.__repository = repository
        self.__start_point = start_point
        self.__moves = [start_point]
        self.__pheromone_map = pheromone_map
        self.__map = current_map
        self.__sensors = sensors
        self.__alpha = alpha
        self.__beta = beta
        self.__fitness = -1
        self.__battery_left = battery
        self.__energy_per_sensor = {}
        self.__initial_intensity = initial_intensity

    def get_fitness(self):
        return self.__fitness

    def get_path(self):
        return self.__moves

    def compute_fitness(self): # we compute the fitness based on the blocks that the sensors reveal
        count = 0
        for sensor in self.__sensors:
            if sensor in self.__moves:
                count += 1
        self.__fitness = count
        coverage_sum = 0
        for sensor in self.__energy_per_sensor:
            coverage_sum += self.__energy_per_sensor[sensor][1]

        return count * 15 + coverage_sum * 15 + 3 * self.__battery_left# count= sensors, cov_sum = blocks discovered by sensor, batt left after it's done

    def get_energy_per_sensor(self):
        return self.__energy_per_sensor

    def select_neighbor(self):
        if self.__battery_left == 0:
            return False
        current_position = self.__moves[-1]
        permitted_neighbors = []
        for neighbor_adder in v:
            neighbor = [current_position[0] + neighbor_adder[0], current_position[1] + neighbor_adder[1]]
            if self.__map.point_is_valid(neighbor) and self.__map.get_point_value(neighbor) != 1 and \
                    neighbor not in self.__moves:
                permitted_neighbors.append(neighbor)# we see the position that are good ( if it's not out of bounds or wall)
        if not permitted_neighbors:
            return False #if the list is empty the ant has nowhere to go
        self.__battery_left -= 1
        for neighbor in permitted_neighbors:# if the postion is a sensro then it will go in
            if neighbor in self.__sensors:
                self.__moves.append(neighbor) #you go on the sensor
                _, closest_sensor = self.next_sensor_value(True)# you see where is the next sensor
                energy = 1
                coverage = len(self.__repository.get_sensor_info(neighbor)[1])# and you start to see how much energy you can give
                if self.__repository.will_reach_sensor(neighbor, closest_sensor, self.__battery_left):
                    for i in range(2, 5 + 1):# it checks how much energy to leave so that it won't be any wast ( it checks with the next sensor)
                        if len(self.__repository.get_sensor_info(neighbor)[i]) >= \
                                len(self.__repository.get_sensor_info(closest_sensor)[i]):
                            energy = i
                            coverage += len(self.__repository.get_sensor_info(neighbor)[i])
                        else:
                            break
                else:
                    for i in range(2, 5 + 1):# if you don;t have energy to make to the next sensor you live the maximum energy possible to this sensor
                        if len(self.__repository.get_sensor_info(neighbor)[i]) > 0:
                            energy = i
                            coverage += len(self.__repository.get_sensor_info(neighbor)[i])
                        else:
                            break
                self.__energy_per_sensor[tuple(neighbor)] = [energy, coverage]
                self.__battery_left -= (energy - 1)
                return True
        if np.random.random() <= Q0:# it has a 50% procent chase to go on the best track so far, it will go in the other neightnors with the best intesity.
            maxi = -1
            maxi_neighbor = None
            for neighbor in permitted_neighbors:
                value = (self.__pheromone_map.get_pheromone_intensity(
                    *neighbor) ** self.__alpha) * self.next_sensor_value()[0]
                if value > maxi:
                    maxi = value
                    maxi_neighbor = neighbor
            self.__moves.append(maxi_neighbor)
        else:
            store_sum = 0
            store = []
            for neighbor in permitted_neighbors:
                value = (self.__pheromone_map.get_pheromone_intensity(
                    *neighbor) ** self.__alpha) * self.next_sensor_value()[0]
                store_sum += value
                store.append(value)

            rand = np.random.uniform(0, store_sum)# random
            index = 0
            for i in range(len(store) - 1):
                if store[i] < rand:
                    index = i + 1
            self.__moves.append(permitted_neighbors[index])
        return True

    def update_pheromone(self):
        current_position = self.__moves[-1]
        previous_position = self.__moves[-2]
        self.__pheromone_map.increase_pheromone_quantity(*current_position)

        new_pheromone_intensity = self.__pheromone_map.get_pheromone_intensity(*current_position)
        new_pheromone_intensity *= (1 - DEGRADATION_COEFFICIENT)

        old_pheromone_intensity = self.__initial_intensity
        old_pheromone_intensity *= DEGRADATION_COEFFICIENT
        self.__pheromone_map.set_pheromone_intensity(*current_position, new_pheromone_intensity +
                                                     old_pheromone_intensity)

    def next_sensor_value(self, is_sensor=False):# it calculates the distance between the ant and next sensors
        current_position = self.__moves[-1]
        min_distance = 1000000
        closest_sensor = None
        for sensor in self.__sensors:
            if sensor not in self.__moves:
                distance = 0
                if is_sensor:
                    distance = self.__repository.get_sensor_distances(current_position)[tuple(sensor)]# if a ant is on the sensor it calc the next sensor distance
                else:
                    distance = manhattan(current_position, sensor)
                if distance < min_distance:
                    min_distance = distance
                    closest_sensor = sensor
        return (1 / min_distance) ** self.__beta, closest_sensor # formula and the next sensor

    def finished(self):# see if the batery is 0 or all the sensors are used checked
        if self.__battery_left == 0:
            return True
        for sensor in self.__sensors:
            if sensor not in self.__moves:
                return False
        return True
