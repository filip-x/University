import json

from aco.acocontroller import ACOController
from aco.acorepository import ACORepository
from gui import MovingDrone, ShowPheromoneMap


class ACOUI:
    def __init__(self, repository):
        self.__aco_repository = ACORepository()
        self.__aco_repository.set_map(repository.get_map())
        self.__controller = None
        self.__solver_parameters = None

    def show_aco_options_menu(self):
        use_config = input("Use config? y/n: ")
        if use_config == "y" or len(use_config) == 0:
            with open(".config") as json_config_file:
                data = json.load(json_config_file)
                self.__solver_parameters = [
                    self.__aco_repository,
                    data["aco"]["iterations_count"],
                    data["aco"]["initial_intensity"],
                    data["aco"]["ant_count"],
                    data["aco"]["alpha"],
                    data["aco"]["beta"],
                    data["aco"]["sensors"],
                    data["aco"]["battery"]
                ]
                self.__controller = ACOController(*self.__solver_parameters)
            print("Successfully loaded the configuration file!")
        else:
            print("Skipping")
        while True:
            print("1. Setup parameters")
            print("2. Run the solver")
            print("3. View the drone moving on a path")
            print("0. Go back to previous menu")
            option = int(input("Enter an option: "))
            if option == 0:
                return
            elif option == 1:
                self.setup_parameters()
            elif option == 2:
                self.solver()
            else:
                print("That option doesn't exist!")

    def setup_parameters(self):
        self.__solver_parameters = [
            self.__aco_repository,
            int(input("iterations count: ")),
            int(input("initial intensity: ")),
            int(input("ant count: ")),
            int(input("alpha: ")),
            int(input("beta: ")),
            int(input("initial battery: ")),
        ]
        sensor_count = int(input("sensor count: "))
        sensors = []
        for i in range(sensor_count):
            x = int(input("Sensor {0} x: ".format(i)))
            y = int(input("Sensor {0} y: ".format(i)))
            sensors.append([x, y])
        self.__solver_parameters.append(sensors)
        self.__controller = ACOController(*self.__solver_parameters)

    def solver(self):
        if not (self.__controller is None or self.__aco_repository.get_map() is None):
            start_point = []  # noqa
            print(" Insert the start point:")
            start_point.append(int(input("> x = ")))
            start_point.append(int(input("> y = ")))
            info = self.__controller.solver(start_point)
            print(*info)
            ShowPheromoneMap(self.__controller.get_pheromone_map(), self.__aco_repository.get_map(),
                             self.__solver_parameters[-2], *info)
            # MovingDrone(self.__aco_repository.get_map(), info[0])
        else:
            raise Exception("Missing parameters or map.")

    def run(self):
        self.show_aco_options_menu()
