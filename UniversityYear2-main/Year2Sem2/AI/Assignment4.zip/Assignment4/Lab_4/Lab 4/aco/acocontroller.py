from aco.domain import PheromoneMap, Ant
from utils import DEGRADATION_COEFFICIENT


class ACOController:
    def __init__(self, repository, iterations_count, initial_intensity, ant_count, alpha, beta, sensors,
                 initial_battery):
        self.__start_point = None
        self.__iterations_count = iterations_count
        self.__ant_colony = []
        self.__ant_count = ant_count
        self.__repository = repository
        self.__alpha = alpha
        self.__beta = beta
        self.__pheromone_map = PheromoneMap(repository.get_map().get_size())
        self.__sensors = sensors
        self.__repository.add_sensors(self.__sensors)
        self.__initial_intensity = initial_intensity
        self.__initial_battery = initial_battery

    def get_pheromone_map(self):
        return self.__pheromone_map

    def iteration(self):
        colony = self.__ant_colony
        current_map = self.__repository.get_map()
        for i in range(self.__ant_count):
            ant: Ant = Ant(self.__start_point, self.__pheromone_map, current_map, self.__repository.get_sensors(),
                           self.__alpha, self.__beta, self.__initial_battery, self.__repository,
                           self.__initial_intensity)
            self.__ant_colony.append(ant)

        finished_ants = []
        while len(colony) > len(finished_ants):#for every ant in the colony it moves one space
            for ant in colony:
                if ant not in finished_ants:
                    response = ant.select_neighbor()
                    if ant.finished():
                        ant.update_pheromone()
                        finished_ants.append(ant)
                        ant.compute_fitness()
                        continue
                    if not response:
                        finished_ants.append(ant)
                        ant.compute_fitness()
                    else:
                        ant.update_pheromone()
        best_ant = max(finished_ants, key=lambda a: a.get_fitness())
        best_fitness = best_ant.get_fitness()
        if best_fitness == 0:
            best_fitness = 1
        unit = 1 / best_fitness
        for move in best_ant.get_path():
            old_intensity = self.__pheromone_map.get_pheromone_intensity(*move)
            new_intensity = (1 - DEGRADATION_COEFFICIENT) * old_intensity + DEGRADATION_COEFFICIENT * unit
            self.__pheromone_map.set_pheromone_intensity(*move, new_intensity)
        return best_ant.get_path(), best_ant.get_energy_per_sensor()

    def run(self):
        best_path = None
        energy_per_sensor = None
        for i in range(self.__iterations_count):
            best_path, energy_per_sensor = self.iteration()
            # if fitness > best_fitness:
            #     best_fitness = fitness
            #     best_path = path
        return best_path, energy_per_sensor

    def solver(self, start_point):
        current_map = self.__repository.get_map()
        self.__start_point = start_point
        for i in range(current_map.get_size()):
            for j in range(current_map.get_size()):
                self.__pheromone_map.set_pheromone_quantity(i, j, 0)
                self.__pheromone_map.set_pheromone_intensity(i, j, self.__initial_intensity)

        return self.run()
