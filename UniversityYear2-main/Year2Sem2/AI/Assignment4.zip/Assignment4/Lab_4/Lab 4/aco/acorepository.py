from aco.domain import manhattan
from repository import Repository
from utils import v


class ACORepository(Repository):
    def __init__(self):
        super().__init__()
        self.__populations = []
        self.__sensors = None
        self.__sensor_info = {}
        self.__sensor_distance = {}

    def add_sensors(self, sensors):
        self.__sensors = sensors
        for sensor in sensors:
            sensor = tuple(sensor)
            self.get_map().set_point(*sensor, -10)
            self.__sensor_info[sensor] = {}
            for i in range(1, 5 + 1):
                self.__sensor_info[sensor][i] = []
            for variation in v:# for each sensor we see how far it can go with as much energy
                d = sensor
                for i in range(1, 5 + 1):
                    d = [d[0] + variation[0], d[1] + variation[1]]
                    if self.get_map().point_is_valid(d) and self.get_map().get_point_value(d) != 1:
                        self.__sensor_info[sensor][i].append(d)
                    else:
                        break
        for sensor1 in sensors:# for every 2 sensors we save the distance between them
            sensor1 = tuple(sensor1)
            self.__sensor_distance[sensor1] = {}
            for sensor2 in sensors:
                sensor2 = tuple(sensor2)
                self.__sensor_distance[sensor1][sensor2] = manhattan(sensor1, sensor2)# change from manhattan
        print(self.__sensor_info)

    def get_sensor_info(self, sensor):
        return self.__sensor_info[tuple(sensor)]

    def get_sensors(self):
        return self.__sensors

    def get_sensor_distances(self, sensor):
        return self.__sensor_distance[tuple(sensor)]

    def get_minimum_coverage(self, sensor):
        return len(self.__sensor_info[tuple(sensor)][1])

    def will_reach_sensor(self, current_sensor, next_sensor, battery_left):
        return battery_left - self.get_sensor_distances(current_sensor)[tuple(next_sensor)] * 1.2 > 0
