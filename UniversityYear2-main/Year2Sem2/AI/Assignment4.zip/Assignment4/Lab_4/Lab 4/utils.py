# Creating some colors
BLUE = (0, 0, 255)
GRAY_BLUE = (50, 120, 120)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)

# define directions
UP = 0
DOWN = 2
LEFT = 1
RIGHT = 3

# define indexes variations
v = [[-1, 0], [1, 0], [0, 1], [0, -1]]

DIRECTIONS_LIST = [UP, DOWN, RIGHT, LEFT]
DIRECTIONS_DICT = {
    UP: v[0],
    DOWN: v[1],
    RIGHT: v[2],
    LEFT: v[3]
}

# define map size
MAP_LENGTH = 20

# seeds
SEEDS = [
    28506, 14260, 97496, 72410, 15585, 53788, 90200, 66928, 34954, 31983,
    84377, 87528, 26842, 69110, 68177, 47603, 58457, 67243, 65985, 31142,
    85670, 14533, 71692, 69354, 7032, 55961, 10488, 34630, 68838, 15309
]

# PHEROMONE DEGRADATION COEFFICIENT
DEGRADATION_COEFFICIENT = 0.2
Q0 = 0.5
