import json

from aco.acoui import ACOUI
from EvolutinLab3.eaui import EAUI
from repository import *


# create a menu
#   1. map options:
#         a. create random map
#         b. load a map
#         c. save a map
#         d. visualise map
#   2. EA options:
#         a. parameters setup
#         b. run the solver
#         c. visualise the statistics
#         d. view the drone moving on a path
#              function gui.movingDrone(currentMap, path, speed, mark_seen)
#              ATTENTION! the function doesn't check if the path passes trough walls

class UI:
    def __init__(self):
        self.__repository = Repository()
        self.__controller = None
        self.__solver_parameters = None

    def show_main_menu(self):
        while True:
            print("1. Map options")
            print("2. EA options")
            print("3. ACO options")
            print("0. Exit")
            # try:
            if True:
                option = int(input("Enter an option: "))
                if option == 0:
                    return
                elif option == 1:
                    self.show_map_options_menu()
                elif option == 2:
                    EAUI(self.__repository).run()
                elif option == 3:
                    ACOUI(self.__repository).run()
                else:
                    print("That option doesn't exist!")
            # except Exception as e:
            #     print("Something went wrong...: " + str(e))

    def show_map_options_menu(self):
        use_config = input("Use config? y/n: ")
        if use_config == "y" or len(use_config) == 0:
            with open(".config") as json_config_file:
                data = json.load(json_config_file)
                map_file_name = data["map"]["map_name"]
                self.__repository.load_map(map_file_name)
            print("Successfully loaded the configuration file!")
        else:
            print("Skipping")
        while True:
            print("1. Create a random map")
            print("2. Load a map")
            print("3. Save a map")
            print("4. Visualize a map")
            print("0. Go back to previous menu")
            try:
                option = int(input("Enter an option: "))
                if option == 0:
                    return
                elif option == 1:
                    self.generate_random_map()
                elif option == 2:
                    self.load_map()
                elif option == 3:
                    self.save_map()
                elif option == 4:
                    self.visualize_map()
                else:
                    print("That option doesn't exist!")
            except Exception as e:
               print("Something went wrong...: " + str(e))

    def generate_random_map(self):
        n = int(input("n = "))
        m = int(input("m = "))
        wall_chance = float(input("Wall chance 0 - 1: "))
        self.__repository.generate_random_map([n, m, wall_chance])

    def save_map(self):
        file_name = input("Enter a file: ")
        self.__repository.save_map(file_name)

    def load_map(self):
        file_name = input("Enter a file: ")
        self.__repository.load_map(file_name)

    def visualize_map(self):
        print(self.__repository.get_map())

    def run(self):
        self.show_main_menu()
