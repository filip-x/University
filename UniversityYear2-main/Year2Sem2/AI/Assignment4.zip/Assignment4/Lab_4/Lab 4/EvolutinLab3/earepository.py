from EvolutinLab3.domain import *
from repository import Repository


class EARepository(Repository):
    def __init__(self):
        super().__init__()
        self.__populations = []

    @staticmethod
    def set_domain_seed(x):
        set_seed(x)

    def clear_populations(self):
        self.__populations.clear()

    def get_last_population(self):
        return self.__populations[-1]

    def save_population(self, pop):
        self.__populations.append(pop)

    def get_fitness_array(self):
        fitness_array = []
        for population in self.__populations:
            best_individual = population.selection(1)[0]
            fitness_array.append(best_individual.get_fitness())
        return fitness_array
