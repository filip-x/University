import numpy as np
from matplotlib import pyplot

from EvolutinLab3.eacontroller import EAController
from EvolutinLab3.earepository import EARepository
from gui import MovingDrone
from utils import SEEDS


class EAUI:
    def __init__(self, repository):
        self.__ea_repository = EARepository()
        self.__ea_repository.set_map(repository.get_map())
        self.__controller = None
        self.__solver_parameters = None

    def show_ea_options_menu(self):
        while True:
            print("1. Setup parameters")
            print("2. Run the solver")
            print("3. Visualize the statistics over 30 runs")
            print("4. Visualize the statistics over 1 run")
            print("5. View the drone moving on a path")
            print("0. Go back to previous menu")
            try:
                option = int(input("Enter an option: "))
                if option == 0:
                    return
                elif option == 1:
                    self.setup_parameters()
                elif option == 2:
                    self.run_solver()
                elif option == 3:
                    self.visualize_statistics_over30_runs()
                elif option == 4:
                    self.visualize_statistics_over1_run()
                elif option == 5:
                    self.move_on_path()
                else:
                    print("That option doesn't exist!")
            except Exception as e:
                print("Something went wrong...: " + str(e))

    def setup_parameters(self):
        self.__solver_parameters = [
            self.__ea_repository,
            int(input("m = ")),
            int(input("population size = ")),
        ]
        self.__controller = EAController(self.__solver_parameters)

    def run_solver(self):
        if self.__controller is None or self.__ea_repository.get_map() is None:
            raise Exception("Missing parameters or map.")
        else:
            start_point = []
            print(" Insert the start point:")
            start_point.append(int(input("> x = ")))
            start_point.append(int(input("> y = ")))
            print(self.__controller.solver([start_point]))

    @staticmethod
    def plot(f):
        x = [i for i in range(len(f))]
        average = np.average(f)
        stdev = np.std(f)
        print("average: {0}, stdev: {1}".format(average, stdev))
        pyplot.plot(x, f)
        pyplot.show()

    def visualize_statistics_over30_runs(self):
        if self.__controller is None or self.__ea_repository.get_map() is None:
            raise Exception("Missing parameters or map.")
        else:
            start_point = []
            print(" Insert the start point:")
            start_point.append(int(input("> x = ")))
            start_point.append(int(input("> y = ")))

            f = []
            for seed in SEEDS:
                self.__controller.set_ea_domain_seed(seed)
                info = self.__controller.solver([start_point])
                f.append(info[1])
            EAUI.plot(f)

    def visualize_statistics_over1_run(self):
        if self.__controller is None or self.__ea_repository.get_map() is None:
            raise Exception("Missing parameters or map.")
        else:
            start_point = []
            print(" Insert the start point:")
            start_point.append(int(input("> x = ")))
            start_point.append(int(input("> y = ")))
            print(self.__controller.solver([start_point]))

            f = self.__controller.get_fitness_array()
            EAUI.plot(f)

    def move_on_path(self):
        if self.__controller is None or self.__ea_repository.get_map() is None:
            raise Exception("Missing parameters or map.")
        else:
            start_point = []
            print(" Insert the start point:")
            start_point.append(int(input("> x = ")))
            start_point.append(int(input("> y = ")))
            info = self.__controller.solver([start_point])
            print(*info)
            MovingDrone(self.__ea_repository.get_map(), info[0])

    def run(self):
        self.show_ea_options_menu()
