from EvolutinLab3.domain import *


class EAController:
    def __init__(self, args):
        self.__repository = args[0]
        self.__m = args[1]
        self.__populationSize = args[2]

    def set_ea_domain_seed(self, new_seed):
        self.__repository.set_ea_domain_seed(new_seed)

    def iteration(self):
        latest_generation = self.__repository.get_last_population()
        parents = latest_generation.selection(4)

        offspring1, offspring2 = parents[0].crossover(parents[1])
        new_generation = latest_generation.copy()

        new_generation.add_individual(offspring1)
        new_generation.add_individual(offspring2)

        new_generation.try_mutate()

        new_generation.evaluate()

        new_generation.remove_weakest()
        new_generation.remove_weakest()

        self.__repository.save_population(new_generation)
        return new_generation

    def iteration_v2(self):
        latest_generation = self.__repository.get_last_population()
        parents = latest_generation.selection(latest_generation.get_size())

        offsprings = []
        for i in range(0, len(parents), 2):
            o1 = parents[i].crossover(parents[i + 1])
            offsprings += [o1]
        new_generation = latest_generation.copy()

        for offspring in offsprings:
            new_generation.add_individual(offspring)

        new_generation.try_mutate()

        new_generation.evaluate()
        for i in range(len(offsprings)):
            new_generation.remove_weakest()

        self.__repository.save_population(new_generation)
        return new_generation

    def run(self):
        no_change_iterations = 0
        maximum_fitness = 0
        while True:
            gen = self.iteration_v2()
            if gen.get_max_fitness() > maximum_fitness:
                maximum_fitness = gen.get_max_fitness()
                no_change_iterations = 0
            else:
                no_change_iterations += 1
                if no_change_iterations > 10:
                    break
        return gen

    def solver(self, args):
        self.__repository.clear_populations()
        initial_population = Population(self.__repository.get_map(), args[0], self.__populationSize, self.__m)
        initial_population.evaluate()
        self.__repository.save_population(initial_population)

        gen = self.run()

        best = gen.selection(1)[0]
        path = best.get_path()
        fitness = best.get_fitness()

        return [path, fitness]

    def get_fitness_array(self):
        return self.__repository.get_fitness_array()
