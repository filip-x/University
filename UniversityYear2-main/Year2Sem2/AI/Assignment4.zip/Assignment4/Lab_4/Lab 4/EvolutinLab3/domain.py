# -*- coding: utf-8 -*-

from random import *
from utils import *
import numpy as np


# the glass gene can be replaced with int or float, or other types
# depending on your problem's representation

def set_seed(val):
    np.random.seed(val)


class Gene:
    def __init__(self, direction=None):
        if direction is None:
            self.direction = np.random.randint(0, len(v))
        else:
            self.direction = direction

    def __eq__(self, other):
        if self.direction == other.direction:
            return True
        return False

    def __hash__(self):
        return hash("{0}".format(self.direction))


class Individual:
    def __init__(self, environment_map, start_point, size=0):
        self.__size = size
        self.__x = [Gene() for _ in range(self.__size)]
        self.__f = None
        self.__map = environment_map
        self.__start = start_point

    def fitness(self):
        explored_points = []
        path = []
        previous = self.__start
        explored_points.append(self.__start)
        path.append(self.__start)
        penalties = 0
        for g in self.__x:
            d = DIRECTIONS_DICT[g.direction]
            gene_pos = [previous[0] + d[0], previous[1] + d[1]]
            explored_points.append(gene_pos)
            previous = gene_pos
            if not (self.__map.point_is_valid(gene_pos) and self.__map.get_point_value(gene_pos) == 0
                    and gene_pos not in path):
                penalties += 1
            path.append(gene_pos)
            for i in range(len(DIRECTIONS_LIST)):
                t = v[i]
                p = [gene_pos[0] + t[0], gene_pos[1] + t[1]]
                while self.__map.point_is_valid(p) and self.__map.get_point_value(p) == 0 \
                        and p not in explored_points:
                    explored_points.append(p)
                    p = [p[0] + t[0], p[1] + t[1]]
        self.__f = len(explored_points) - penalties * 10

    def get_x(self):
        return self.__x

    def get_size(self):
        return self.__size

    def mutate(self, mutate_probability=0.04):
        for i in range(len(self.__x)):
            if random() < mutate_probability:
                k = np.random.randint(0, len(DIRECTIONS_LIST))
                self.__x[i] = Gene(DIRECTIONS_LIST[k])

    def crossover(self, other_parent, crossover_probability=0.8):
        offspring = Individual(self.__map, self.__start, self.__size)
        if np.random.random() < crossover_probability:
            for i in range(self.get_size()):
                if np.random.random() < 0.5:
                    offspring.get_x()[i] = self.get_x()[i]
                else:
                    offspring.get_x()[i] = other_parent.get_x()[i]
        return offspring

    def get_path(self):
        path = []
        previous = self.__start
        path.append(self.__start)
        for g in self.__x:
            d = DIRECTIONS_DICT[g.direction]
            gene_pos = [previous[0] + d[0], previous[1] + d[1]]
            previous = gene_pos
            path.append(gene_pos)
        return path

    def copy(self):
        cloned = Individual(self.__map, self.__start, self.__size)
        cloned.get_x().clear()
        e = cloned.get_x()
        e += self.get_x()
        return cloned

    def get_fitness(self):
        return self.__f


class Population:
    def __init__(self, environment_map, start_point, population_size=0, individual_size=0):
        self.__populationSize = population_size
        self.__individualSize = individual_size
        self.__mapM = environment_map
        self.__startPoint = start_point
        self.__v = [Individual(environment_map, start_point, individual_size) for _ in range(population_size)]
        self.__maxFitness = 0

    def get_size(self):
        return self.__populationSize

    def copy(self):
        new_pop = Population(self.__mapM, self.__startPoint, self.__populationSize, self.__individualSize)
        new_pop.get_individuals().clear()
        for x in self.__v:
            new_pop.get_individuals().append(x.copy())
        return new_pop

    def get_max_fitness(self):
        return self.__maxFitness

    def remove_weakest(self):
        weakest = min(self.__v, key=lambda i: i.get_fitness())
        self.__v.remove(weakest)

    def add_individual(self, ind):
        self.__v.append(ind)

    def try_mutate(self):
        for x in self.__v:
            x.mutate()

    def get_individuals(self):
        return self.__v

    def evaluate(self):
        for x in self.__v:
            x.fitness()
            if x.get_fitness() > self.__maxFitness:
                self.__maxFitness = x.get_fitness()

    def selection(self, k=0):
        if k == 0:
            return []
        e = self.__v[:]
        e.sort(key=lambda x: x.get_fitness(), reverse=True)
        return e[:k]
