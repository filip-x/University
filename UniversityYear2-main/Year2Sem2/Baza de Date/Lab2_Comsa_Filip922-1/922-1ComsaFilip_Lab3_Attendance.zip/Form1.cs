﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace Lab1ComsaFilip922_1
{
    public partial class Form1 : Form
    {
        SqlConnection connection;
        DataSet dataSet;//a local copy of my data  
        SqlDataAdapter artistAdaptor, songArtistAdaptor;// conn dataSet->database
        SqlCommandBuilder command;//it helps the adaptor make commands 
        BindingSource artistSource, songArtistSource; // it connects the dataSet to the datagridview (songTable and Artist_SongTable)

        public Form1()
        {
            InitializeComponent();
        }

        private void Update_Click(object sender, EventArgs e)
        {
            songArtistAdaptor.Update(dataSet, "Song_Artist");//update database
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            connection = new SqlConnection(@"Data Source = DESKTOP-PE6HT4H\SQLEXPRESS; Initial Catalog = Spopple_Music; Integrated Security = SSPI;");
            dataSet = new DataSet();
            artistAdaptor = new SqlDataAdapter("select * from Artist", connection);
            songArtistAdaptor = new SqlDataAdapter("select * from Song_Artist", connection);
            command = new SqlCommandBuilder(songArtistAdaptor);

            songArtistAdaptor.Fill(dataSet, "Song_Artist");//fill dataSet
            artistAdaptor.Fill(dataSet, "Artist");
            DataRelation relationBetweenData = new DataRelation("FK__Song_Artist_Artist", dataSet.Tables["Artist"].Columns["Artist_id"], dataSet.Tables["Song_Artist"].Columns["Artist_id"]);
            //dataRelation helps us to not change(delete/update) the data that are in use (for integrity)
            dataSet.Relations.Add(relationBetweenData);

            artistSource = new BindingSource();
            artistSource.DataSource = dataSet;
            artistSource.DataMember = "Artist";

            songArtistSource = new BindingSource();
            songArtistSource.DataSource = artistSource;
            songArtistSource.DataMember = "FK__Song_Artist_Artist";

            songArtistTable.DataSource = songArtistSource;
            artistTable.DataSource = artistSource;
        }
    }
}
