#include <exception>
#include "BagIterator.h"
#include "Bag.h"

using namespace std;


BagIterator::BagIterator(const Bag& c): bag(c)
{
	//TODO - Implementation
}

void BagIterator::first() {
	//TODO - Implementation
}


void BagIterator::next() {
	//TODO - Implementation
}


bool BagIterator::valid() const {
	//TODO - Implementation
	return false;
}



TElem BagIterator::getCurrent() const
{
	//TODO - Implementation
	return NULL_TELEM 
}
