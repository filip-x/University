#include "SetIterator.h"
#include "Set.h"


SetIterator::SetIterator(const Set& m) : set(m)
{
	//TODO - Implementation
}


void SetIterator::first() {
	//TODO - Implementation
}


void SetIterator::next() {
	//TODO - Implementation
}


TElem SetIterator::getCurrent()
{
	//TODO - Implementation
	return NULL_TELEM;
}

bool SetIterator::valid() const {
	//TODO - Implementation
	return false;
}



