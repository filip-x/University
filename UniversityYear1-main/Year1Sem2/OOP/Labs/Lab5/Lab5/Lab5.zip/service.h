#pragma once
#include"repo.h"
typedef struct {

	repository_of_supplies list;
}controller;

controller create_service();
void adding_supplies(controller* service, int location_code_to_be_added, char store_type_to_be_added[], char supply_type_to_be_added[], int complexity_to_be_added);
void update_supply(controller* service, int location_code_to_update, char store_type_update[], char supply_type_update[], int complexity_update);
void delete_supply(controller* service, int location_code_to_delete);
void list_of_supplies(controller* service, void (*print_supply)(supply));
void list_of_supplies_by_criteria(controller* service, char supply_type[], void(*print_supply)(supply));
int verification_existence_of_supply(controller service, int location_code_to_search);


