#include "supply.h"
#include "repo.h"
#include"service.h"
#include <string.h>



controller create_service()
{
	controller service;
	service.list = create_element();
	return service;
}
void adding_supplies(controller *service,int location_code_to_be_added,char store_type_to_be_added[],char supply_type_to_be_added[],int complexity_to_be_added)
{
	int i;
	supply item_to_be_added = create_supply(location_code_to_be_added, store_type_to_be_added, supply_type_to_be_added, complexity_to_be_added);

	append_function(&service->list, item_to_be_added);
}
void update_supply(controller* service, int location_code_to_update,char store_type_update[],char supply_type_update[],int complexity_update)
{
	supply update_item = create_supply(location_code_to_update, store_type_update, supply_type_update, complexity_update);
	update_of_the_list(&service->list, location_code_to_update, update_item);

}
void delete_supply(controller* service, int location_code_to_delete)
{
	remove_function(&service->list,location_code_to_delete);
}

void list_of_supplies(controller* service,void (*print_supply)(supply))
{
	int counter = getter_count_of_supplies(&service->list);
	supply* list = getter_list_of_supplies(&service->list);
	int i;
	for (i = 0; i < counter; i++)
	{
		print_supply(list[i]);
	}
}
void list_of_supplies_by_criteria(controller* service,char supply_type[],void(*print_supply)(supply))
{
	int counter = getter_count_of_supplies(&service->list);
	supply* list = getter_list_of_supplies(&service->list);
	char supply_type_to_find[256];
	
	int i;
	for (i = 0; i < counter; i++)
	{
		getter_supply_type(list[i], supply_type_to_find);
		if(strcmp(supply_type_to_find,supply_type)==0)
			print_supply(list[i]);
	}
}
int verification_existence_of_supply(controller service, int location_code_to_search)
{
	if (getter_location(search_of_the_list(service.list, location_code_to_search)) == -1)
		return 0;
	else
		return 1;
}