#include "repo.h"
#include<string.h>





 repository_of_supplies create_element()
 {
	int count_supplies = 0;

	repository_of_supplies supplies;
	supplies.count_of_supplies = count_supplies;
	return supplies;
 }



 supply search_of_the_list(repository_of_supplies repo_supplies,int location_code_search)// we have a function supply because we return a element of the list that is of type supplies
 {
	 int i;
	 supply none_element = {.location_code =-1};// initialisation in the declaration ( if the list has not the location_code that we desire)
	 for(i=0;i<repo_supplies.count_of_supplies;i++)
	 { 
		 if (repo_supplies.list_of_supplies[i].location_code == location_code_search)
			 return repo_supplies.list_of_supplies[i];
	 }
	 return none_element;
 }

 void append_function(repository_of_supplies* repo_supplies, supply appending_element)
 {
	 int i =repo_supplies->count_of_supplies;//este ultimul element deja
	 repo_supplies->list_of_supplies[i] = appending_element;
	 repo_supplies->count_of_supplies++;

 }

 void remove_function(repository_of_supplies* repo_supplies, int location_code_remove)
 {
	 int i;
	 int j;
	 for (i = 0; i < repo_supplies->count_of_supplies; i++)
	 {
		 if (repo_supplies->list_of_supplies[i].location_code == location_code_remove)
		 {
			 for (j = i + 1; j < repo_supplies->count_of_supplies; j++)
				 repo_supplies->list_of_supplies[j - 1] = repo_supplies->list_of_supplies[j];
			 break;
		 }
	 }
	 repo_supplies->count_of_supplies--;

 }

 void update_of_the_list(repository_of_supplies* repo_supplies, int location_code_search, supply information_update)// we have a function supply because we return a element of the list that is of type supplies
 {
	 int i;
	 for (i = 0; i < repo_supplies->count_of_supplies; i++)
	 {
		 if (repo_supplies->list_of_supplies[i].location_code == location_code_search)
		 {
			 repo_supplies->list_of_supplies[i].store_lock_complexity = information_update.store_lock_complexity;
			 strcpy(repo_supplies->list_of_supplies[i].store_type, information_update.store_type);
			 strcpy(repo_supplies->list_of_supplies[i].supply_type, information_update.supply_type);
		 }
	 }
 }
 
 int getter_count_of_supplies(repository_of_supplies* repo_supplies)
 {
	 return repo_supplies->count_of_supplies;
 }
 supply* getter_list_of_supplies(repository_of_supplies* repo_supplies)
 {
	 return repo_supplies->list_of_supplies;
 }