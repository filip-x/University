#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "supply.h"
#include "repo.h"
#include "service.h"
// this is the UI





void print_on_screen(supply element)
{
	char saving_the_store_type_to_display[256];
	char saving_the_supply_type_to_display[256];
	getter_supply_type(element, saving_the_supply_type_to_display);
	getter_store_type(element, saving_the_store_type_to_display);
	printf("Location Code: %d / Store Type: %s / Supply Type: %s / Complexity: %d \n", getter_location(element), saving_the_store_type_to_display, saving_the_supply_type_to_display, getter_store_lock_complexity(element));
}

void print_of_the_menu()
{
	printf("List of commands you can use!!!");
	printf("\n1.Add\n");
	printf("2.Update\n");
	printf("3.Delete\n");
	printf("4.List\n");
	printf("5.List Supply type\n");
}

int validation_if_number_is_int( char value[])
{
	int length_of_the_value = strlen(value)-1;
	int i;
	for (i = 0; i <= length_of_the_value; i++)
	{
		if (value[i] < '0' || value[i] > '9')
			return 0;
	
	}
	return 1;

}
int validation(char initial_command[100],char first_command_argument[100],char second_command_argument[100],char third_command_argument[100],char fourth_command_argument[100])
{
	if (strcmp(initial_command, "add") != 0 && strcmp(initial_command, "update") != 0 && strcmp(initial_command, "delete") != 0 && strcmp(initial_command,"list"))
		return 0;
	if (strcmp(initial_command, "list") == 0)
		return 1;
	if (strcmp(initial_command, "add") == 0)
	{
		if (strlen(first_command_argument) == 0 || strlen(second_command_argument) == 0 || strlen(third_command_argument) == 0 || strlen(fourth_command_argument) == 0)
			return 0;
		else
		{
			if (validation_if_number_is_int(first_command_argument) == 1 && validation_if_number_is_int(fourth_command_argument) == 1)
				return 1;
		}
				
	}
	if (strcmp(initial_command, "update") == 0)
	{
		if (strlen(first_command_argument) == 0 || strlen(second_command_argument) == 0 || strlen(third_command_argument) == 0 || strlen(fourth_command_argument) == 0)
			return 0;
		else
		{
			if (validation_if_number_is_int(first_command_argument) == 1 && validation_if_number_is_int(fourth_command_argument) == 1)
				return 1;
		}

	}
	if (strcmp(initial_command, "delete") == 0)
	{
		if (strlen(first_command_argument) == 0)
			return 0;
		else
		{
			if (validation_if_number_is_int(first_command_argument) == 1)
				return 1;
		}
	}
}


void extracting_the_command_arguments(char saving_the_user_input[256],char initial_command[100],char first_command_argument[100],char second_command_argument[100],char third_command_argument[100],char fourth_command_argument[100])
{
	
	
	int counter_for_the_command = 0;
	char* p = strtok(saving_the_user_input, ", \n");
	while (p != NULL)
	{
		if (counter_for_the_command == 0)
			strcpy(initial_command, p);
		if (counter_for_the_command == 1)
			strcpy(first_command_argument, p);
		if (counter_for_the_command == 2)
			strcpy(second_command_argument, p);
		if (counter_for_the_command == 3)
			strcpy(third_command_argument, p);
		if (counter_for_the_command == 4)
			strcpy(fourth_command_argument, p);
		if (counter_for_the_command == 5)
			break;
			
		counter_for_the_command++;
		p = strtok(NULL, ", \n");
	}
	
}
int string_into_int(char string[])
{
	int i;
	int int_number=0;
	int length = strlen(string);
	for (i = 0; i < length; i++)
	{
		int_number = 10 * int_number + string[i] - '0';
	}
	return int_number;
}

void starting()
{
	controller service = create_service();
	char saving_the_user_input[256];
	char initial_command[100];
	char first_command_argument[100] ="";
	char second_command_argument[100]="";
	char third_command_argument[100]="";
	char fourth_command_argument[100]="";

	do
	{
		first_command_argument[0] = '\0';
		second_command_argument[0] = '\0';
		third_command_argument[0] = '\0';
		fourth_command_argument[0] = '\0';

		printf("Write a command:\n");
		fgets(saving_the_user_input, 256, stdin);
		extracting_the_command_arguments(saving_the_user_input,initial_command, first_command_argument, second_command_argument, third_command_argument, fourth_command_argument);
		if (strcmp(initial_command, "exit") == 0)
		{
			return;
		}
		if (validation(initial_command, first_command_argument, second_command_argument, third_command_argument, fourth_command_argument) == 0)
		{
			printf("The command is not good!");
			continue;
		}
		if (strcmp(initial_command, "add") == 0)
		{
			int location_code_int = 0;
			int complexity_code_int = 0;
			char* location_code_string = first_command_argument;
			char* store_type_string = second_command_argument;
			char* supply_type_string = third_command_argument;
			char* complexity_code_string = fourth_command_argument;
			location_code_int = string_into_int(location_code_string);
			complexity_code_int = string_into_int(complexity_code_string);
			if (verification_existence_of_supply(service, location_code_int) == 1)
			{
				printf("No!");
				continue;
			}
			adding_supplies(&service, location_code_int, store_type_string, supply_type_string, complexity_code_int);
		}
		if (strcmp(initial_command, "update") == 0)
		{
			int location_code_int = 0;
			int complexity_code_int = 0;
			char* location_code_string = first_command_argument;
			char* store_type_string = second_command_argument;
			char* supply_type_string = third_command_argument;
			char* complexity_code_string = fourth_command_argument;
			location_code_int = string_into_int(location_code_string);
			complexity_code_int = string_into_int(complexity_code_string);
			if (verification_existence_of_supply(service, location_code_int) == 0)
			{
				printf("No!");
				continue;
			}
			update_supply(&service, location_code_int, store_type_string, supply_type_string, complexity_code_int);
		}
		if (strcmp(initial_command, "delete") == 0)
		{
			int location_code_int = 0;
			char* location_code_string = first_command_argument;
			location_code_int = string_into_int(location_code_string);
			if (verification_existence_of_supply(service, location_code_int) == 0)
			{
				printf("No!");
				continue;
			}
			delete_supply(&service, location_code_int);
		}

		if (strcmp(initial_command, "list") == 0)
		{
			char* supply_type_string = first_command_argument;
			if (strlen(supply_type_string) > 0)
			{
				list_of_supplies_by_criteria(&service, supply_type_string, print_on_screen);
			}
			else
			{
				list_of_supplies(&service, print_on_screen);
			}
		}
	} while (1);

}


int main()
{
	starting();
	return 0;
}