#pragma once 
#include <exception>
using namespace std;
class Exceptions :public exception 
{
    using exception::exception;
};

