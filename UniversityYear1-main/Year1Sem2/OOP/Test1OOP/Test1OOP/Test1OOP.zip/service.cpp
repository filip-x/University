#include "service.h"

Service::Service()
{
}

Service::~Service()
{
}
