#pragma once

class Service
{
public:
	Service();
	~Service();

private:

};
